// config.js

// Creator name for API responses and display
global.creator = "@bebas";

// Telegram Bot API Token
// Ganti 'TOKEN BOT' dengan token bot Telegram Anda yang sebenarnya.
// Dapatkan dari @BotFather di Telegram.
global.telegram_api_token = "7771429262:AAHwRR2VVM0Wlh1LWsmk9V3ZRifx8RZUU9Y"; // Token Anda

// Telegram Chat ID
// Ganti 'USER ID' dengan ID chat pribadi atau grup Anda
// tempat Anda ingin menerima notifikasi.
global.telegram_chat_id = "6878949999"; // Chat ID Anda

// Watermark for various uses (e.g., messages sent by bot)
global.watermark = "© bebas";